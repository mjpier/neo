<!--
This repository is for the Wayland protocol description and the libwayland IPC helper
library only. Issues with Wayland during day-to-day usage are almost
certainly a bug in your compositor and **not** a bug with in this
repository.

Please remove this comment before filing your bug.
-->
