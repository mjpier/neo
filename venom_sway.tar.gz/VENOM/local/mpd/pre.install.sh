#!/bin/sh

useradd -c "mpd music daemon"  -d  /var/lib/mpd -s /bin/false -g audio -g mpd mpd 2>/dev/null

exit 0

